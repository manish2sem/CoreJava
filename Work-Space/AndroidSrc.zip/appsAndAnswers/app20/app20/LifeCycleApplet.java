package app20;

import java.applet.Applet;
import java.awt.Graphics;

public class LifeCycleApplet extends Applet {
    StringBuilder stringBuilder = new StringBuilder();

    public void init() {
        stringBuilder.append("init()... ");
    }

    public void start() {
        stringBuilder.append("start()... ");
    }

    public void stop() {
        stringBuilder.append("stop()... ");
    }

    public void destroy() {
        stringBuilder.append("destroy()... ");
    }

    public void paint(Graphics g) {
        stringBuilder.append("paint(g)... ");
        // g.drawRect(0, 0, size().width - 1, size().height - 1);
        g.drawString(stringBuilder.toString(), 5, (size().height / 2));
    }

}

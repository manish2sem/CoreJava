package app20;

import java.applet.Applet;
import java.applet.AudioClip;

public class SoundPlayerApplet extends Applet {
    public void start() {
        AudioClip audioClip = this.getAudioClip(getCodeBase(), "quack.au");
        // audioClip.play();
        audioClip.loop();
    }
}

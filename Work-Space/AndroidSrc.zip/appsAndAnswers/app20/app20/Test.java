package app20;

import java.util.ArrayList;
import java.util.List;

public class Test {

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        List<String> list = new ArrayList<String>();
        list.add("one");
        list.add("two");
        String[] s = new String[2];
        list.toArray(s);
        for (String x : s)
            System.out.println(x);
    }

}

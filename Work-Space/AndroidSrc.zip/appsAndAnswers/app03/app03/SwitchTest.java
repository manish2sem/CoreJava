package app03;

public class SwitchTest {
  public static void main(String[] args) {
    int i = 4;
    switch (i) {
    case 1 : 
      System.out.println("There will be one player playing this game.");
      break; 
    case 2 : 
      System.out.println("There will be two players playing this game.");
      break;
    case 3 : 
      System.out.println("There will be three players playing this game.");
      break;
    default: 
      System.out.println("You did not enter a valid value");
    }
  }
}

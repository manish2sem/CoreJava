package app03;

public class ForTest {

  /**
   * @param args
   */
  public static void main(String[] args) {
    System.out.println("Example 1");
    for (int i=0; i<3; i++) {
      System.out.println(i + "  ");
    }
    
    System.out.println("Example 2");
    for (int i=0; i<3; i++) {
      if (i%2==0)
        System.out.println(i);
    }
    
    System.out.println("Example 3");
    for (int i=0; i<3; i+=2) {
      System.out.println(i);
    }

    System.out.println("Example 4");
    for (int i=3; i>0; i--) {
      System.out.println(i);
    }

    System.out.println("Example 5");
    int j=0;
    for ( ; j<3; j++) {
      System.out.println(j);
    }

    System.out.println("Example 6");
    int k=0;
    for ( ; k<3; ) {
      System.out.println(k);
      k++;
    }
    
    System.out.println("Example 7");
    int m=0;
    for ( ; ; ) {
      System.out.println(m);
      m++;
      if (m>2) {
        break;
      }
    }

  }

}

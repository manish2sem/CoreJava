package app03;

public class DoWhileTest {

  public static void main(String[] args) {
    int i=0;
    do {
      System.out.println(i);
      i++;
    } while (i<3);

    int j=4;
    do {
      System.out.println(j);
      j++;
    } while (j<3);

  }

}

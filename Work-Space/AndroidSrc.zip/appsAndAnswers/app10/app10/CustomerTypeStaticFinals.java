package app10;
public class CustomerTypeStaticFinals {
  public static final int INDIVIDUAL = 1;
  public static final int ORGANIZATION = 2;
}

package app10;
public class OldFashionedCustomer {
  public String customerName;
  public int customerType;
  public String address;
}

package app10;
public enum CustomerType { 
  INDIVIDUAL, 
  ORGANIZATION 
}

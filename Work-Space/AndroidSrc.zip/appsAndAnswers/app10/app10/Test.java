package app10;

public class Test {

    public enum Sex {
        MALE, FEMALE
    };

    public static void main(String[] args) {
        Customer customer = new Customer();
        customer.customerType = CustomerType.INDIVIDUAL;
        

        switch (customer.customerType) {
        case INDIVIDUAL:
            System.out.println("Customer Type: Individual");
            break;
        case ORGANIZATION:
            System.out.println("Customer Type: Organization");
            break;
        }
        OldFashionedCustomer ofCustomer = new OldFashionedCustomer();
        ofCustomer.customerType = 5;

        Shape shape = new Shape();
        System.out.println(shape);

        System.out.println(CustomerType.values().getClass().getName());
        for (CustomerType customerType : CustomerType.values()) {
            System.out.println("Customer Type: " + customerType);
        }
    }
}

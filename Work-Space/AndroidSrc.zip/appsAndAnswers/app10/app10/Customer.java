package app10;
public class Customer {
  public String customerName;
  public CustomerType customerType;
  public String address;
}

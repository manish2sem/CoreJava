package app06;

class Animal {
    public float weight;
    public void eat() {
    }
}

class Bird extends Animal {
    public int numberOfWings = 2;
    public void fly() {
    }
}

class Fish extends Animal {
    public int numberOfFins = 2;
    public void swim() {
    }
}

class Dog extends Animal {
    public int numberOfLegs = 4;
    public void walk() {
    }
}


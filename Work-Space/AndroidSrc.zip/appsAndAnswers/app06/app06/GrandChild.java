package app06;

public class GrandChild extends Child {
}

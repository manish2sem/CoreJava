package app24;

import java.awt.FlowLayout;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import javax.swing.JFrame;
import javax.swing.JLabel;

/*
 * a rewrite of Listing 23.4
 *
 */
public class ExecutorTest1 extends JFrame {
    JLabel countUpLabel = new JLabel("Count Up");
    JLabel countDownLabel = new JLabel("Count Down");

    public ExecutorTest1(String title) {
        super(title);
        init();
    }

    private void init() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setLayout(new FlowLayout());
        this.add(countUpLabel);
        this.add(countDownLabel);
        this.pack();
        this.setVisible(true);

        Runnable countUp = new Runnable() {
            public void run() {
                int count = 0;
                while (true) {
                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException e) {
                    }
                    if (count == 1000) {
                        count = 0;
                    }
                    countUpLabel.setText(Integer.toString(count++));
                }
            }

        };

        Runnable countDown = new Runnable() {
            public void run() {
                int count = 1000;
                while (true) {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                    }
                    if (count == 0) {
                        count = 1000;
                    }
                    countDownLabel.setText(Integer.toString(count--));
                }
            }

        };


        Executor executor = Executors.newFixedThreadPool(2);
        // if you pass 1 to the newFixedThreadPool method, the second thread will never
        // get a chance to run
        executor.execute(countUp);
        executor.execute(countDown);
    }

    private static void constructGUI() {
        JFrame.setDefaultLookAndFeelDecorated(true);
        ExecutorTest1 frame = new ExecutorTest1("Executor Test 1");
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                constructGUI();
            }
        });
    }
}

package com.brainysoftware.common;

public class StringUtil {

    public String toMixedCase(String s) {
        return null;
    }

}

package com.brainysoftware.component;

public class HtmlParser {

    /**
     * Convert the specified string according to Rule A. You can also use the
     * {@link com.brainysoftware.common.StringUtil#toMixedCase(java.lang.String) StringUtil.toMixedCase}
     * method.
     * 
     * @param s
     *            the String to be converted
     * @return A new String object converted according to Rule A.
     * @see com.brainysoftware.common.StringUtil#toMixedCase(java.lang.String)
     *      StringUtil.toMixedCase method
     */
    public String convertString(String s) {
        return null;
    }
}

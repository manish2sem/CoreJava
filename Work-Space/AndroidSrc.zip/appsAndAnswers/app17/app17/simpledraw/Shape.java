package app17.simpledraw;

import java.awt.Color;
import java.awt.Graphics;

interface Shape {
    public void draw(Graphics g);
}

class Rectangle implements Shape {
    // (x1,y1) = mouse press coordinate
    public int x1, y1, x2, y2;

    public Rectangle(int x1, int y1, int x2, int y2) {
        this.x1 = x1 < x2 ? x1 : x2;
        this.y1 = y1 < y2 ? y1 : y2;
        this.x2 = x1 < x2 ? x2 : x1;
        this.y2 = y1 < y2 ? y2 : y1;
    }

    public void draw(Graphics g) {
        g.setColor(Color.green);
        g.fill3DRect(x1, y1, x2 - x1, y2 - y1, true);
    }
} // end of class Rectangle

class Line implements Shape {
    int x1, y1, x2, y2;

    public Line(int x1, int y1, int x2, int y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    public void draw(Graphics g) {
        g.setColor(Color.red);
        g.drawLine(x1, y1, x2, y2);
    }
} // end of class Line

class Oval implements Shape {
    int x1, y1, x2, y2;

    public Oval(int x1, int y1, int x2, int y2) {
        this.x1 = x1 < x2 ? x1 : x2;
        this.y1 = y1 < y2 ? y1 : y2;
        this.x2 = x1 < x2 ? x2 : x1;
        this.y2 = y1 < y2 ? y2 : y1;
    }

    public void draw(Graphics g) {
        g.setColor(Color.yellow);
        g.fillOval(x1, y1, x2 - x1, y2 - y1);
    }
} // end of class Oval

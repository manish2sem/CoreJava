package app17;

// this example shows that polymorphism 
// does not work with static methods.
class Car {
    public static void drive() {
        System.out.println("I am a Car.");
    }
}

class Sedan extends Car {
    public static void drive() {
        System.out.println("I am a Sedan.");
    }
}

public class PolymorphismTest2 {
    public static void main(String[] args) {
        Car car = new Sedan();
        car.drive(); // print "I am a Car"
    }
}

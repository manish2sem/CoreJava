package app17;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MyFrame extends JFrame {

    JLabel label = new JLabel("Welcome");

    JButton button1 = new JButton("Blue");

    JButton button2 = new JButton("Green");

    public void initialize() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("My Swing Application");
        this.setLayout(new FlowLayout());
        this.getContentPane().add(label);
        this.getContentPane().add(button1);
        this.getContentPane().add(button2);
        button1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                brightenForegroundColor(label);
            };
        });
        button2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                brightenForegroundColor(button2);
            };
        });
        this.pack();
        this.setVisible(true);
    }

    public static void brightenForegroundColor(Component component) {
        Color oldColor = component.getForeground();
        int red = oldColor.getRed();
        int green = oldColor.getGreen();
        int blue = oldColor.getBlue();
        if (red < 245) {
            red += 10;
        }    
        if (green < 245) {
            green += 10;
        }
        if (blue < 245) {
            blue += 10;
        }
        Color newColor = new Color(red, green, blue);
        component.setForeground(newColor);
    }

    public static void main(String[] args) {
        MyFrame frame = new MyFrame();
        frame.initialize();

    }

}

package app05;

public class SystemPropertiesTest {

  public static void main(String[] args) {
    java.util.Properties properties = System.getProperties();
    properties.list(System.out);
  }

}

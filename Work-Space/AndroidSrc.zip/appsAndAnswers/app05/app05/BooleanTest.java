package app05;

public class BooleanTest {
    public static void main(String[] args) {
        Boolean b1 = new Boolean(false);
        Boolean b2 = new Boolean("true");
        System.out.println(Character.isDigit('1'));
        System.out.println(Character.isDigit('0'));
        System.out.println(Character.isDigit('9'));
        System.out.println(Character.isDigit('+'));
        System.out.println(Character.isDigit('-'));
        System.out.println(Character.isDigit('a'));

    }

}

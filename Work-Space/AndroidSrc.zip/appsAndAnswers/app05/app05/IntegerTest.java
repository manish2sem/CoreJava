package app05;

public class IntegerTest {
    public static void main(String[] args) {
        Integer i1 = new Integer(12);
        Integer i2 = new Integer("123");
        System.out.println(i1);
        System.out.println(i2);
    }

}

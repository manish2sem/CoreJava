package app05;

public class StringTest {
  public static void main(String[] args) {
    System.out.println("Java is cool".charAt(0)); // returns 'J'
    System.out.println("Java ".concat("is cool")); // returns "Java is cool"
    System.out.println("Java is cool".indexOf("cool")); // returns 8
    System.out.println("Java is cool".lastIndexOf("a")); // returns 3
    System.out.println("Java is cool".substring(8)); // returns "cool"
//    System.out.println("Java is cool".substring(5, 7)); // returns "is"
    System.out.println("Java is cool".length()); // returns 12
    System.out.println("  Java ".trim()); // returns "Java"
    System.out.println("dingdong".replace('d', 'k')); // returns "kingkong"
    System.out.println("Java is cool".toLowerCase()); // returns "java is cool"
    System.out.println("Java is cool".toUpperCase()); // returns "JAVA IS COOL"
    String[] elements = "Java is cool".split(" ");
    
    for (String element : elements) {
      System.out.println(element);
    }  
  }
}

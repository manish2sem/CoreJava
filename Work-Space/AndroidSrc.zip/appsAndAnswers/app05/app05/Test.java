package app05;

public class Test {
  public void print() {
    System.out.println("Hello World");
  }
}

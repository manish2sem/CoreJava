package app05;

public class BoxingTest {
    public static void main(String[] args) {
        Integer number = new Integer(100);
        int[] ints = new int[2];
        ints[0] = number;
    }

}

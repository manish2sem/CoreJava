package app05;
public class ArrayCloningTest {
  public static void main(String[] args) {
    int[] array1 = { 1, 2};
    int[] array2 = array1.clone();
    array1[0] = 10;
    for (int i : array1)
      System.out.println(i);
    for (int i : array2)
      System.out.println(i);
  }
}

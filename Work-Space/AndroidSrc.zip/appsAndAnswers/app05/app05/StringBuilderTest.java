package app05;

public class StringBuilderTest {

    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder(100);
        System.out.println(sb.capacity());  // returns 100
        System.out.println(sb.length());  // returns 0
        sb.append("Matrix ");
        sb.append(2);
        
        StringBuilder sb2 = new StringBuilder(100);
        sb2.append("night");
        sb2.insert(0, 'k'); // becomes knight
        System.out.println(sb2);

    }

}

package app05;
import java.util.Scanner;

public class ArrayTest {
    public static void main(String[] args) {
        int[] numbers = new int[4];
        System.out.println(numbers[2]);
        System.out.println("Size:" + numbers.length);
        System.out.println("Type:" + numbers.getClass().getName());
        System.out.println("Is Array:" + numbers.getClass().isArray());

        long longs[] = new long[2];

        System.out.println(numbers[1]);
        String[] names = { "John", "Mary", "Paul" };
        for (String name : names) {
            System.out.println(name);
        }

        System.out.println(names[1]);
        int[] matrix = { 1, 2, 3, 10 };
        System.out.println(matrix[2]);

    }

}

package app05;

import java.util.Calendar;

public class FormatTest {
    public static void main(String[] args) {
        String firstName = "John";
        String lastName = "Adams";
        System.out.printf("First name: %s. Last name: %s",
                firstName, lastName);
        System.out.println("First name: " + firstName + 
                ". Last name: " + lastName);
        
        int a = 65;
        int b = 66;
        System.out.printf("First name: %x. Last name: %x",
                a, b);
    }

}

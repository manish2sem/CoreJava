package app05;
public class ArrayOfArrayTest {
  public static void main(String[] args) {
    int[][] aa = new int[3][2];
    aa[0][0] = 1;
    
    // TODO Auto-generated method stub

  }

}

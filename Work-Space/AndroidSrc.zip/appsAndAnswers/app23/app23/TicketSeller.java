package app23;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

class TicketHolder {
    private String ticketNumber;

    private boolean available = false;

    public synchronized String buy(String buyerName) {
        while (!available) {
            try {
                wait(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        String purchasedTicketNumber = new String(ticketNumber);
        ticketNumber = null;
        available = false;
        notifyAll();
        return purchasedTicketNumber;
    }

    public synchronized void cancel(String ticketNumber) {
        while (available) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();

            }
        }
        this.ticketNumber = ticketNumber;
        available = true;
        notifyAll();
    }
}

public class TicketSeller extends JFrame {
    List<Thread> threadList = new ArrayList<Thread>();

    TicketHolder ticketHolder = new TicketHolder();

    public TicketSeller() {
        init();
    }

    class CancelThread extends Thread {
        String ticketNumber;

        public CancelThread(String ticketNumber) {
            this.ticketNumber = ticketNumber;
        }

        public void run() {
            ticketHolder.cancel(ticketNumber);
        }
    }

    class BuyThread extends Thread {
        String buyerName;

        public BuyThread(String buyerName) {
            this.buyerName = buyerName;
        }

        public void run() {
            String ticketPurchased = ticketHolder.buy(buyerName);
            if (ticketPurchased != null) {
                System.out
                        .println(buyerName + " got ticket " + ticketPurchased);
            }
        }
    }

    private void init() {
        this.getContentPane().setLayout(new FlowLayout());
        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String ticketNumber = JOptionPane.showInputDialog(
                        TicketSeller.this, "Ticket Number:");
                if (ticketNumber != null) {
                    CancelThread thread = new CancelThread(ticketNumber);
                    threadList.add(thread);
                    thread.start();
                }
            }
        });
        JButton buyButton = new JButton("Buy");
        buyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String buyerName = JOptionPane.showInputDialog(
                        TicketSeller.this, "Buyer Name");
                if (buyerName != null) {
                    BuyThread thread = new BuyThread(buyerName);
                    threadList.add(thread);
                    thread.start();
                }
            }
        });
        JButton listButton = new JButton("List Threads");
        listButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                for (Thread thread : threadList) {
                    Thread.State state = thread.getState();
                    if (state == Thread.State.NEW)
                        System.out.println("NEW");
                    if (state == Thread.State.RUNNABLE)
                        System.out.println("RUNNABLE");
                    if (state == Thread.State.BLOCKED)
                        System.out.println("BLOCKED");
                    if (state == Thread.State.TIMED_WAITING)
                        System.out.println("TIMED_WAITING");
                    if (state == Thread.State.WAITING)
                        System.out.println("WAITING");
                    if (state == Thread.State.TERMINATED)
                        System.out.println("TERMINATED");
                }
                System.out.println("---------------------");
            }
        });
        this.getContentPane().add(cancelButton);
        this.getContentPane().add(buyButton);
        this.getContentPane().add(listButton);

    }

    private static void constructGUI() {
        JFrame.setDefaultLookAndFeelDecorated(true);
        TicketSeller frame = new TicketSeller();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                constructGUI();
            }
        });
    }
}

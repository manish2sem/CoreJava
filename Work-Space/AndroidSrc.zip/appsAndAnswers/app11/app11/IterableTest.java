package app11;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class IterableTest {
    public static void main(String[] args) {
        List myList = new ArrayList();
        myList.add("Yes");
        myList.add("Hello");
        myList.add("World");

        Iterator iterator = myList.iterator();
        while (iterator.hasNext()) {
            String element = (String) iterator.next();
            System.out.println(element);
        }

        for (Iterator iterator2 = myList.iterator(); iterator2.hasNext();) {
            String element = (String) iterator2.next();
            System.out.println(element);
        }
        for (Object object : myList) {
            System.out.println(object);
        }
    }
}

package app11;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

public class CollectionConvertTest {

    public static void main(String[] args) {
        // convert Queue to List
        Queue queue = new LinkedList();
        queue.add("Hello");
        queue.add("World");
        List list = new ArrayList(queue);
        for (Object object : list)
            System.out.println(object);

        // convert List to Set, duplicates will be removed
        List myList = new ArrayList();
        myList.add("Hello");
        myList.add("World");
        myList.add("World");
        System.out.println("------");
        for (Object object : myList)
            System.out.println(object);

        System.out.println("------");
        Set set = new HashSet(myList);
        for (Object object : set)
            System.out.println(object);
    }

}

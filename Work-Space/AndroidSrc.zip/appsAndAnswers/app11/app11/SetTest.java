package app11;

import java.util.Set;
import java.util.HashSet;

public class SetTest {
    public static void main(String[] args) {
        Set set = new HashSet();
        set.add("Hello");
        if (set.add("Hello"))
            System.out.println("addition successful");
        else
            System.out.println("addition failed");
        set.add(null);
        for (Object object : set)
            System.out.println(object);

    }

}

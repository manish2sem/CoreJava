package app15;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class JPanelTest extends JFrame {

    public void Initialize() {
        this.setLayout(new BorderLayout());
        this.setSize(300, 100);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("JPanel Test");

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        this.setContentPane(panel);

        JPanel panelTop = new JPanel();
        JLabel labelTopLeft = new JLabel("Top left panel");
        JLabel labelTopRight = new JLabel("Top right panel");
        panelTop.setLayout(new FlowLayout());
        panelTop.add(labelTopLeft);
        panelTop.add(labelTopRight);
        panelTop.setBackground(Color.yellow);
        panel.add(panelTop, BorderLayout.NORTH);

        JPanel panelBottom = new JPanel();
        panelBottom.setBackground(Color.red);
        panel.add(panelBottom, BorderLayout.SOUTH);

        this.pack();
        this.setVisible(true);
    }

    public static void main(String[] args) {
        JPanelTest panelTest = new JPanelTest();
        panelTest.Initialize();
    }
}

package app15;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class JOptionPaneTest1 {

    public static void main(String[] args) {

        JDialog.setDefaultLookAndFeelDecorated(true);
        //JOptionPane.showMessageDialog(null, "Message");

        JOptionPane.showMessageDialog(null, "Thank you for visiting our store",
                "Thank You", JOptionPane.INFORMATION_MESSAGE);

        JOptionPane.showMessageDialog(null, "You have not saved this document",
                "Warning", JOptionPane.WARNING_MESSAGE);

        JOptionPane.showMessageDialog(null, "First Name must have a value",
                "Error", JOptionPane.ERROR_MESSAGE);
    }
}

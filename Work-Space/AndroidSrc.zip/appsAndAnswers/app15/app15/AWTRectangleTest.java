package app15;

import java.awt.Frame;
import java.awt.Label;
import java.awt.Rectangle;
import java.awt.FlowLayout;

public class AWTRectangleTest extends Frame {

    public void initialize() {
        this.setTitle("AWT Rectangle Test");

        Rectangle rectangle = new Rectangle(50, 50, 300, 100);
        Rectangle rectangle2 = new Rectangle(10, 10, 200, 50);
        rectangle.add(rectangle2);
        this.setBounds(rectangle);
        this.setVisible(true);
    }

    public static void main(String arg[]) {
        AWTRectangleTest awtRectangleTest = new AWTRectangleTest();
        awtRectangleTest.initialize();
    }
}

package app15;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

public class JOptionPaneTest2 {
    public static void main(String[] args) {
        String input = JOptionPane.showInputDialog(null, 
                "Enter Your Name", "John Average");

        int response = JOptionPane.showConfirmDialog(null,
                "Do you want to continue?", "Confirm",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (response == JOptionPane.NO_OPTION) {
            System.out.println("No button clicked");
        } else if (response == JOptionPane.YES_OPTION) {
            System.out.println("Yes button clicked");
        } else if (response == JOptionPane.CLOSED_OPTION) {
            System.out.println("JOptionPane closed");
        }
    }
}

package app09;
public class MyPrinter extends DefaultPrinter {
    public void print(Object document) {
        System.out.println("Printing document");
        // some code here
    }
}

package app09;
public class CanonDriver implements Printable {
    public void print(Object obj) {
        // code that does the printing
    }
}

package app09;
import java.util.Arrays;
public class MyUtil {
  public static void sort(Comparable[] array) throws ClassCastException {
    Arrays.sort(array);
  }
}

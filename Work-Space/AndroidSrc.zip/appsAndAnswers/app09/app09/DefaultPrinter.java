package app09;
public abstract class DefaultPrinter {
    public String toString() {
        return "Use this to print documents.";
    }
    public abstract void print(Object document);
}

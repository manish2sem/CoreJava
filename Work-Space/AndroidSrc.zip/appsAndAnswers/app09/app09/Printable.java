package app09;
public interface Printable {
    void print(Object o);
}

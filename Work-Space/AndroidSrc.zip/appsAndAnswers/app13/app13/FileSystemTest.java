package app13;

import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Path;

public class FileSystemTest {
    public static void main(String[] args) {
        FileSystem fileSystem = FileSystems.getDefault();
        System.out.println(fileSystem.getSeparator());
        for (Path root : fileSystem.getRootDirectories()) {
            System.out.println(root);
        }
    }
}

package app13;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamTest {
    public void copyFiles(String originPath, String destinationPath)
            throws IOException {
        File originFile = new File(originPath);
        File destinationFile = new File(destinationPath);
        if (!originFile.exists() || destinationFile.exists()) {
            throw new IOException(
                    "Origin file must exist and " + 
                    "Destination file must not exist");
        }
        try {
            byte[] readData = new byte[1024];
            FileInputStream fis = new FileInputStream(originFile);
            FileOutputStream fos = new FileOutputStream(destinationFile);
            int i = fis.read(readData);
            while (i != -1) {
                fos.write(readData, 0, i);
                i = fis.read(readData);
            }
            fis.close();
            fos.close();
        } catch (IOException e) {
            throw e;
        }
    }

    public static void main(String[] args) {
        FileOutputStreamTest test = new FileOutputStreamTest();
        try {
            test.copyFiles("c:\\temp\\line1.bmp", "c:\\temp\\line3.bmp");
            System.out.println("Copied Successfully");
        } catch (IOException e) {
        }
    }
}
package app13;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class BufferedReaderTest {
    
    public static void main(String[] args) {
        Path textFile = Paths.get("C:\\temp\\myFile.txt");
        Charset chineseSimplifiedCharset = Charset.forName("GB2312");
        char[] chars = new char[2];
        chars[0] = '\u4F60'; // representing ?
        chars[1] = '\u597D'; // representing ?;

        try {
            try (BufferedWriter writer = Files.newBufferedWriter(textFile, 
                         chineseSimplifiedCharset, 
                         StandardOpenOption.CREATE)) {
                writer.write(chars);
            }
        } catch (IOException e) {
            System.out.println(e.toString());
        }

        // read back textFile1 and write to textFile2
        Path textFile2 = Paths.get("C:\\temp\\myFile2.txt");
        try (BufferedReader bufferedReader = 
                Files.newBufferedReader(textFile, chineseSimplifiedCharset);
            BufferedWriter writer = Files.newBufferedWriter(textFile2, 
                    chineseSimplifiedCharset, StandardOpenOption.CREATE)) {
            char[] chars2 = new char[2];
            bufferedReader.read(chars2);
            System.out.print(chars2[0]);
            System.out.println(chars2[1]);
            writer.write(chars2);
        } catch (IOException e) {
            System.out.println(e.toString());
        }
        
//        Charset utf8Charset = Charset.forName("UTF-8");
//        try (BufferedReader bufferedReader = 
//                Files.newBufferedReader(textFile, utf8Charset)) {
//            char[] chars2 = new char[2];
//            bufferedReader.read(chars2); // fail here
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
    }

}

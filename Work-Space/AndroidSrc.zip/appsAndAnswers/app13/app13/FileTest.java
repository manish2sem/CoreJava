package app13;

import java.io.File;
import java.io.IOException;

public class FileTest {
    public static void main(String[] args) {
        File file1 = new File("C:\\temp\\myNote.txt");
        try {
            file1.createNewFile();
        } catch (IOException e) {
            System.out.println(e.toString());
        }
        File file2 = new File("/tmp/myNote.txt");
        try {
            file2.createNewFile();
        } catch (IOException e) {
            System.out.println(e.toString());
        }

        File file3 = new File("music");
        System.out.println(file3.getAbsolutePath());
        File dir1 = new File("C:\\temp\\notes");
        dir1.mkdir();

        File dir2 = new File("/tmp/notes");
        dir2.mkdir();

        System.out.println(File.pathSeparator);
        System.out.println(File.separatorChar);
    }

}

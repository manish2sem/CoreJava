package app19;

import java.util.Locale;

public class LocaleTest {

    public static void main(String[] args) {
        Locale locale1 = new Locale("en", "CA");
        Locale locale2 = Locale.CANADA_FRENCH;
    }
}

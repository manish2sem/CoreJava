package app18;

public class DeprecatedTest {
    @Deprecated
    public void serve() {
    }
}

package app18;

public class OverrideTest2 {
    @Override
    public String toString() {
        return "OverrideTest2";
    }
}

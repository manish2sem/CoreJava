package app18;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;

@SuppressWarnings(value = { "unchecked", "serial" })
public class SuppressWarningsTest implements Serializable {
    public void openFile() {
        ArrayList a = new ArrayList();
        File file = new File("X:/java/doc.txt");
    }
}

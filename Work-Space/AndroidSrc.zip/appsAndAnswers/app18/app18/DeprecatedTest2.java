package app18;

public class DeprecatedTest2 {
    public static void main(String[] args) {
        DeprecatedTest test = new DeprecatedTest();
        test.serve();
    }
}

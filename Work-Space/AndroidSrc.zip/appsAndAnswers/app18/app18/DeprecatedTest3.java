package app18;

@Deprecated
public class DeprecatedTest3 {
    public void serve() {
    }
}

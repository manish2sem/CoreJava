package app18;

class Parent {
    public float calculate(float a, float b) {
        return a * b;
    }
}

public class OverrideTest extends Parent {
    // you should use @Override when overriding a method
    public int calculate(int a, int b) {
        return (a + 1) * b;
    }
}

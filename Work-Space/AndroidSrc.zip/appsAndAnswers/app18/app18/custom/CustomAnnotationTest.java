package app18.custom;

public class CustomAnnotationTest {
    public static void printClassInfo(Class c) {
        System.out.print(c.getName() + ". ");
        Author author = (Author) c.getAnnotation(Author.class);
        if (author != null) {
            System.out.println("Author:" + author.firstName() 
                    + " " + author.lastName());
        } else {
            System.out.println("Author unknown");
        }    
    }

    public static void main(String[] args) {
        CustomAnnotationTest.printClassInfo(Test1.class);
        CustomAnnotationTest.printClassInfo(Test2.class);
        CustomAnnotationTest.printClassInfo(Test3.class);
        CustomAnnotationTest.printClassInfo(
                CustomAnnotationTest.class);
    }
}

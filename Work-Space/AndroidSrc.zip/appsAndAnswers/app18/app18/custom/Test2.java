package app18.custom;

@Author(firstName = "John", lastName = "Guddell", internalEmployee = true)
public class Test2 {

}

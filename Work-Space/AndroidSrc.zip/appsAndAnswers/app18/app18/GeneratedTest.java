package app18;

import javax.annotation.Generated;

@Generated(value="com.brainysoftware.robot.CodeGenerator",
        date="2010-12-31", comments="Generated code")
public class GeneratedTest {
}

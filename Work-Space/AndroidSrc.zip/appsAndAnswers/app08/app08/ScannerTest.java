package app08;
import java.util.Scanner;
public class ScannerTest {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    String s = scanner.next();
    System.out.println("You entered: " + s);
  }
}

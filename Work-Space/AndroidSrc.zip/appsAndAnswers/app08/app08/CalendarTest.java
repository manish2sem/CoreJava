package app08;

import java.util.Calendar;

public class CalendarTest {
    public static void main(String[] args) {
        Calendar calendar = Calendar.getInstance();
        int month = calendar.get(Calendar.MONTH);
        switch (month) {
        case Calendar.JANUARY:
            System.out.println("January");
            break;
        case Calendar.DECEMBER:
            System.out.println("December");
            break;
        }
        System.out.println(calendar.get(Calendar.MONTH));

    }

}

package app08;
import java.util.Date;

public class DateTest {

  public static void main(String[] args) {
    Date date1 = new Date(1000);
    Date date2 = new Date(1001);
    if (date1.before(date2))
      System.out.println("date1 before date2");
    else
      System.out.println("date1 not before date2");
      
    System.out.println(new Date(0)); 
    
    
  }

}

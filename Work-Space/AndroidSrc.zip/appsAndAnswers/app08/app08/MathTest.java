package app08;
public class MathTest {
    public static void main(String[] args) {
        System.out.println(Math.E);
        System.out.println((double) 22/7);
    }
}

public class PageChild extends Page {

    /**
     * @param args
     */
    public void doIt() {
        Page page = new Page();
        int i = getPageNumber();
        
    }
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }

}

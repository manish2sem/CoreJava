
public class Employee {
    Address address = new Address();
}

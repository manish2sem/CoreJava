package app04;


public class StaticDemo {
    int b = 8;
    static final float pi = (float) 22 / 7;
    
    public static void main(String[] args) {
        int i;
        System.out.println(pi);
    }

}

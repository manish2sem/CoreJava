package app04;
public class MathUtil {
    public static int add(int a, int b) {
        return a + b;
    }
}

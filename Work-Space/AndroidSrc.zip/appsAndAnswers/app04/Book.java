
public class Book {
    String isbn;
    String title;
    int width;
    int height;
    int numberOfPages;
    Chapter getChapter() {
        Object object = new Object();
        object.toString();
        return new Chapter();
    }
}

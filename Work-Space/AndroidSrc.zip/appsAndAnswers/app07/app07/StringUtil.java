package app07;

public class StringUtil {
    public String capitalize(String s) 
            throws NullPointerException, AlreadyCapitalizedException {
        if (s == null) {
            throw new NullPointerException("Your passed a null argument");
        }
        Character firstChar = s.charAt(0);
        if (Character.isUpperCase(firstChar)) {
            throw new AlreadyCapitalizedException();
        }
        String theRest = s.substring(1);
        return firstChar.toString().toUpperCase() + theRest;
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        StringUtil util = new StringUtil();
        String input = "Capitalize";
        try {
            String capitalized = util.capitalize(input);
            System.out.println(capitalized);
        } catch (NullPointerException e) {
            System.out.println(e.toString());
        } catch (AlreadyCapitalizedException e) {
            e.printStackTrace();
        }

    }

}

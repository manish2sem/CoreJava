package app07;
public class AlreadyCapitalizedException extends Exception {
    public String toString() {
        return "Input has already been capitalized";
    }
}

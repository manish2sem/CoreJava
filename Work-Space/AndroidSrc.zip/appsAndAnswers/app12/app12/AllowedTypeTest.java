package app12;

import java.util.ArrayList;
import java.util.List;

public class AllowedTypeTest {
  public static void doIt(List<Object> l) {
}
  public static void main(String[] args) {
    List<String> myList = new ArrayList<String>();
    // the following line would generate a compile error
    // doIt(myList);
  }
}

package app12;

import java.util.ArrayList;
import java.util.List;

public class LowerBoundTest {
    
  public static double test(List<? super Integer> numberList) {
    return 0.0;
  }
   
  public static void main(String[] args) {
    // TODO Auto-generated method stub
    List<Integer> integerList = new ArrayList<Integer>();
    integerList.add(3);
    integerList.add(30);
    integerList.add(300);
    System.out.println(test(integerList)); // 111.0
    List<Number> numberList = new ArrayList<Number>();
    numberList.add(3.0);
    numberList.add(33.0);
    System.out.println(test(numberList)); // 18.0

    List<Double> doubleList = new ArrayList<Double>();
    doubleList.add(3.0);
    doubleList.add(33.0);
    // this would generate a compile error
    //System.out.println(test(doubleList)); // 18.0
  }

}

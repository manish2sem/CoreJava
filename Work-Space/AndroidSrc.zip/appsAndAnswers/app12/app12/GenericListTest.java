package app12;

import java.util.List;
import java.util.ArrayList;

public class GenericListTest {

  public static void main(String[] args) {
    List stringList1 = new ArrayList();
    stringList1.add("Java");
    stringList1.add("with generics");
    // cast to java.lang.String
    String s1 = (String) stringList1.get(0);
    System.out.println(s1.toUpperCase());
    
    // now with generics
    List<String> stringList2 = new ArrayList<String>();
    stringList2.add("Java");
    stringList2.add("with generics");
    // no need to typecast
    String s2 = stringList2.get(0);
    System.out.println(s2.toUpperCase());
    
  }

}

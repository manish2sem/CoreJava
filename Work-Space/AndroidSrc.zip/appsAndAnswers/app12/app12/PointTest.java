package app12;

public class PointTest {

  public static void main(String[] args) {
    Point<Integer> point1 = new Point<Integer>(4, 2);
    point1.setX(7);
    
    Point<Double> point2 = new Point<Double>(1.3, 2.6);
    point2.setX(109.91);
  }

}

package app14;

class Outer1 {
  private static int value = 9;
  static class Nested1 {
    int calculate() {
      return value; 
    }
  }
}

public class StaticNestedTest1 {
  public static void main(String[] args) {
    Outer2.Nested2 nested = new Outer2.Nested2();
    System.out.println(nested.calculate());
  }
}

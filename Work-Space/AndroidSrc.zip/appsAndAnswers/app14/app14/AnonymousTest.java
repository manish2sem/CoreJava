package app14;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

public class AnonymousTest extends JFrame {
  JButton button = new JButton("Select File");
  String selectedFilePath;
  
  public void initialize () {
    this.setSize(300,100);
    this.setTitle("JFileChooser Test");
    this.setLayout(new FlowLayout());
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent ae) {
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(AnonymousTest.this);
        if (returnValue==JFileChooser.APPROVE_OPTION) {
          selectedFilePath = fileChooser.getSelectedFile().getAbsolutePath();
          System.out.println(selectedFilePath);
        }
      }
    });
    this.add(button);
    this.pack();
    this.setVisible(true);
  }
  
  public static void main (String[] args) {
    AnonymousTest test = new AnonymousTest();
    test.initialize();
  }
}

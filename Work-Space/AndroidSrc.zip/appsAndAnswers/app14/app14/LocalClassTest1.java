package app14;

import java.util.Date;

interface Logger {
  public void log(String message);
}

public class LocalClassTest1 {
  String appStartTime = (new Date()).toString();
  public Logger getLogger() {
    class LoggerImpl implements Logger {
      public void log(String message) {
        System.out.println(appStartTime + " : " + message);
      }
    }
    return new LoggerImpl();
  }
  
  public static void main(String[] args) {
    LocalClassTest1 test = new LocalClassTest1();
    Logger logger = test.getLogger();
    logger.log("Local class example");
  }

}
